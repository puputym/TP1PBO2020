﻿using Pembelian.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pembelian
{
    public partial class FrmBeli : Form
    {
        public ListItem[] listitems = new ListItem[6];
        public FrmBeli()
        {
            InitializeComponent();
        }

        private void FrmBeli_Load(object sender, EventArgs e)
        {
            PopulateItem();
            
        }

        private void PopulateItem()
        {
            label2.Visible = false;
            for (int i = 0; i < listitems.Length; i++)
            {
                listitems[i] = new ListItem();
                if (i == 0)
                {
                    listitems[i].Judul  = "PULSA";
                    listitems[i].Harga  = "Rp.100.000";
                    listitems[i].Icon   = Resources.pulsa;
                    listitems[i].Button = "btnBeli1";
                }else if(i == 1)
                {
                    listitems[i].Judul = "PAKET DATA";
                    listitems[i].Harga = "Rp.200.000";
                    listitems[i].Icon = Resources.data;
                    listitems[i].Button = "btnBeli2";
                }
                else if (i == 2)
                {
                    listitems[i].Judul = "PLN";
                    listitems[i].Harga = "Rp.300.000";
                    listitems[i].Icon = Resources.listrik;
                    listitems[i].Button = "btnBeli3";
                }
                else if (i == 3)
                {
                    listitems[i].Judul = "E-DANA";
                    listitems[i].Harga = "Rp.1000.000";
                    listitems[i].Icon = Resources.wallet;
                    listitems[i].Button = "btnBeli4";
                }
                else if (i == 4)
                {
                    listitems[i].Judul = "VOUCHER";
                    listitems[i].Harga = "Rp.750.000";
                    listitems[i].Icon = Resources.game;
                    listitems[i].Button = "btnBeli5";
                }
               

                if(flowLayoutPanel1.Controls.Count < 0)
                {
                    flowLayoutPanel1.Controls.Clear();
                }
                else
                flowLayoutPanel1.Controls.Add(listitems[i]);
                
            }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cbHarga_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
            if (cbJenis.SelectedItem == null || cbHarga.SelectedItem == null)
            {
                MessageBox.Show("Harap Masukan Jenis Barang / Range Harga");
                PopulateItem();
            }
            else
            {
                if(cbJenis.SelectedItem == "Elektronik")
                {
                    if(cbHarga.SelectedItem == "100.000 - 200.000")
                    {
                        label2.Visible = true;
                        flowLayoutPanel1.Controls.Add(listitems[0]);
                    }else if(cbHarga.SelectedItem == "200.000 - 500.000")
                    {
                        label2.Visible = true;
                        flowLayoutPanel1.Controls.Add(listitems[1]);
                    }
                    else
                    {
                        MessageBox.Show("BARANG LAGI KOSONG");
                        PopulateItem();
                    }
                }
                else if(cbJenis.SelectedItem == "Baju")
                {
                    if (cbHarga.SelectedItem == "100.000 - 200.000")
                    {
                        MessageBox.Show("BARANG LAGI KOSONG");
                        PopulateItem();
                    }
                    else if (cbHarga.SelectedItem == "200.000 - 500.000")
                    {
                        MessageBox.Show("BARANG LAGI KOSONG");
                        PopulateItem();
                    }
                    else
                    {
                        label2.Visible = true;
                        flowLayoutPanel1.Controls.Add(listitems[2]);
                        flowLayoutPanel1.Controls.Add(listitems[3]);
                    }
                }
                else if (cbJenis.SelectedItem == "Makanan")
                {
                    if (cbHarga.SelectedItem == "100.000 - 200.000")
                    {
                        label2.Visible = true;
                        flowLayoutPanel1.Controls.Add(listitems[4]);
                    }
                    else if (cbHarga.SelectedItem == "200.000 - 500.000")
                    {
                        label2.Visible = true;
                        flowLayoutPanel1.Controls.Add(listitems[5]);
                    }
                    else
                    {
                        MessageBox.Show("BARANG LAGI KOSONG");
                        PopulateItem();
                    }
                }
            }
            
        }
    }
}
