﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pembelian
{
    public partial class FrmHome : Form
    {
        FrmBeli formBeli = new FrmBeli();
        User user = new User();
        public FrmHome()
        {
            InitializeComponent();
            txtName.Text = "Selamat Datang" + user.Username;
        }



        private void pictureBox2_Click(object sender, EventArgs e)
        {
            formBeli.TopLevel = false;
            PnlUtama.Controls.Add(formBeli);
            formBeli.Show();
        }

        private void PnlUtama_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            FromLogin frmLogin = new FromLogin();
            frmLogin.Show();
            this.Hide();
        }

       
    }
}
